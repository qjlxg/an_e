module.exports = require('@umijs/fabric').prettier;
