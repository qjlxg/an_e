---
title: 首页
hero:
  title: 前端知识库
  desc: 记录 js 知识点
  actions:
    - text: Link Start
      link: /base
features:
  - icon: /images/node.svg
    title: Node
    desc: Node 原理
    link: /node
  - icon: /images/react.svg
    title: React
    desc: React 原理及全家桶
  - icon: /images/vue.svg
    title: Vue
    desc: Vue 原理及全家桶
    link: https://aslkami-vue.netlify.app/
# footer: Open-source MIT Licensed | Copyright © 2022<br />Powered by [dumi](https://d.umijs.org)
footer: 本文档由 [dumi](https://d.umijs.org/zh-CN) 生成， [欢迎 Star](https://github.com/aslkami/aslkami.github.io)
---
