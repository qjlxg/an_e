export default {
  navs: [
    {
      title: '前端工程化',
      path: '/pack-tool',
    },
  ],
  menus: {},
};
