export default {
  navs: [
    {
      title: 'React',
      path: '/react',
    },
  ],
  menus: {},
};
