---
title: ReduxToolkit
order: 1
---

## ReduxTookit 是什么

[ReduxTookit](https://redux-toolkit.js.org/) 是官方的，开箱即用的高效 Redux 开发工具集，类似于 dva，简化了写 Redux 的流程代码，即对 Redux 高度优化封装

## 安装

```js
npm install @reduxjs/toolkit
```

## 调试插件

[传送门](https://github.com/reduxjs/redux-devtools)
