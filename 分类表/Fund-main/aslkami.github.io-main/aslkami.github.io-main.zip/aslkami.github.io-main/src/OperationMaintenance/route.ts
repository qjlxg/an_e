export default {
  navs: [
    {
      title: '前端运维',
      path: '/operation-maintenance',
    },
  ],
  menus: {
    '/operation-maintenance': [
      {
        title: 'Linux 基础',
        path: '/operation-maintenance/linux',
      },
    ],
  },
};
