export default {
  navs: [
    {
      title: 'CSS',
      path: '/css',
    },
  ],
};
