### 缩放组件

<code src="./ScaleSlider/index.jsx" />
